﻿CREATE TYPE [dbo].[RecipeMealType] AS TABLE (
    [RecipeName]   VARCHAR (25) NULL,
    [MealTypeName] VARCHAR (25) NULL);

