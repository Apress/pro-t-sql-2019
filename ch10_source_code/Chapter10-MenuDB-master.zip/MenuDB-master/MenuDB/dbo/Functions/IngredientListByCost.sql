﻿CREATE   FUNCTION dbo.IngredientListByCost (@Cost DECIMAL(6,3))
RETURNS @Output TABLE
(
	IngredientID			INT,
    IngredientName			VARCHAR(25),
	IngredientCost			DECIMAL(6,3)
)
AS
    BEGIN
        INSERT INTO @Output (IngredientID, IngredientName, IngredientCost)
        SELECT   ing.IngredientID, ing.IngredientName, ingcos.Cost
        FROM     dbo.Ingredient ing
			INNER JOIN dbo.IngredientCost ingcos
			ON ing.IngredientID = ingcos.IngredientID
        WHERE	 ingcos.Cost > @Cost;
        RETURN;
    END;
