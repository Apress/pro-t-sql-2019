﻿CREATE TABLE [dbo].[Ingredient] (
    [IngredientID]   INT           IDENTITY (1, 1) NOT NULL,
    [IngredientName] VARCHAR (25)  NOT NULL,
    [IsActive]       BIT           NOT NULL,
    [DateCreated]    DATETIME2 (7) NOT NULL,
    [DateModified]   DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_Ingredient_IngredientID] PRIMARY KEY CLUSTERED ([IngredientID] ASC)
);

