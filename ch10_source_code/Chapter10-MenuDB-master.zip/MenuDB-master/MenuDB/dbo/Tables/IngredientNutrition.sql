﻿CREATE TABLE [dbo].[IngredientNutrition] (
    [IngredientNutritionID] INT           IDENTITY (1, 1) NOT NULL,
    [ServingPortionID]      TINYINT       NOT NULL,
    [Calories]              TINYINT       NOT NULL,
    [Carbohydrates]         TINYINT       NOT NULL,
    [Sugar]                 TINYINT       NOT NULL,
    [Fiber]                 TINYINT       NOT NULL,
    [Protein]               TINYINT       NOT NULL,
    [IsActive]              BIT           NOT NULL,
    [DataCreated]           DATETIME2 (7) NOT NULL,
    [DateModified]          DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_IngredientNutrition_IngredientNutritionID] PRIMARY KEY CLUSTERED ([IngredientNutritionID] ASC),
    CONSTRAINT [FK_IngredientNutrition_ServingPortionID] FOREIGN KEY ([ServingPortionID]) REFERENCES [dbo].[ServingPortion] ([ServingPortionID])
);

