﻿CREATE TABLE [dbo].[IngredientCostHistory] (
    [IngredientCostHistoryID] INT            IDENTITY (1, 1) NOT NULL,
    [IngredientCostID]        INT            NOT NULL,
    [Cost]                    DECIMAL (6, 3) NOT NULL,
    [DateCreated]             DATETIME2 (7)  NOT NULL,
    CONSTRAINT [PK_IngredientCost_IngredientCostHistoryID] PRIMARY KEY CLUSTERED ([IngredientCostHistoryID] ASC),
    CONSTRAINT [FK_IngredientCost_IngredientCostID] FOREIGN KEY ([IngredientCostID]) REFERENCES [dbo].[IngredientCost] ([IngredientCostID])
);

