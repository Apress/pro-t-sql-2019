﻿CREATE TABLE [dbo].[RecipeIngredient] (
    [RecipeIngredientID] INT           IDENTITY (1, 1) NOT NULL,
    [RecipeID]           SMALLINT      NOT NULL,
    [IngredientID]       INT           NOT NULL,
    [ServingPortionID]   TINYINT       NOT NULL,
    [IsActive]           BIT           NOT NULL,
    [DateCreated]        DATETIME2 (7) NOT NULL,
    [DateModified]       DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_RecipeIngredient_RecipeIDIngredientID] PRIMARY KEY CLUSTERED ([RecipeID] ASC, [IngredientID] ASC),
    CONSTRAINT [FK_RecipeIngredient_IngredientID] FOREIGN KEY ([IngredientID]) REFERENCES [dbo].[Ingredient] ([IngredientID]),
    CONSTRAINT [FK_RecipeIngredient_RecipeID] FOREIGN KEY ([RecipeID]) REFERENCES [dbo].[Recipe] ([RecipeID])
);


GO
CREATE NONCLUSTERED INDEX [NDX_RecipeIngredient_IsActive_IngredientID]
    ON [dbo].[RecipeIngredient]([IsActive] ASC, [IngredientID] ASC);

