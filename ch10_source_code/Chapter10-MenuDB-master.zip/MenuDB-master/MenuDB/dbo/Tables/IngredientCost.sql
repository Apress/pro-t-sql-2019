﻿CREATE TABLE [dbo].[IngredientCost] (
    [IngredientCostID] INT            IDENTITY (1, 1) NOT NULL,
    [IngredientID]     INT            NOT NULL,
    [ServingPortionID] TINYINT        NOT NULL,
    [Cost]             DECIMAL (6, 3) NOT NULL,
    [IsActive]         BIT            NOT NULL,
    [DateCreated]      DATETIME2 (7)  NOT NULL,
    [DateModified]     DATETIME2 (7)  NOT NULL,
    CONSTRAINT [PK_IngredientCost_IngredientCostID] PRIMARY KEY CLUSTERED ([IngredientCostID] ASC),
    CONSTRAINT [FK_IngredientCost_IngredientID] FOREIGN KEY ([IngredientID]) REFERENCES [dbo].[Ingredient] ([IngredientID]),
    CONSTRAINT [FK_IngredientCost_ServingPortionID] FOREIGN KEY ([ServingPortionID]) REFERENCES [dbo].[ServingPortion] ([ServingPortionID])
);


GO
CREATE TRIGGER dbo.LogIngredientCostHistory  
ON dbo.IngredientCost  
AFTER INSERT, UPDATE   
AS 
	IF (ROWCOUNT_BIG() = 0)
	RETURN;

	INSERT INTO dbo.IngredientCostHistory (IngredientCostID, Cost, DateCreated)
	SELECT inserted.IngredientCostID, inserted.cost, GETDATE()
	FROM inserted;  
