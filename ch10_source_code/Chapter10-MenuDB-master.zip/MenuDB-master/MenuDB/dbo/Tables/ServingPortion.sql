﻿CREATE TABLE [dbo].[ServingPortion] (
    [ServingPortionID]       TINYINT       IDENTITY (1, 1) NOT NULL,
    [ServingPortionQuantity] TINYINT       NOT NULL,
    [ServingPortionUnit]     VARCHAR (4)   NOT NULL,
    [IsActive]               BIT           NOT NULL,
    [DateCreated]            DATETIME2 (7) NOT NULL,
    [DateModified]           DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_ServingPortion_ServingPortionID] PRIMARY KEY CLUSTERED ([ServingPortionID] ASC)
);

