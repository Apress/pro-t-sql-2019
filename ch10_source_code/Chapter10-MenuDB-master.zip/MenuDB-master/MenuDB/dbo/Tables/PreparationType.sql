﻿CREATE TABLE [dbo].[PreparationType] (
    [PreparationTypeID]          TINYINT       IDENTITY (1, 1) NOT NULL,
    [PreparationTypeName]        VARCHAR (25)  NOT NULL,
    [PreparationTypeDescription] VARCHAR (50)  NOT NULL,
    [IsActive]                   BIT           NOT NULL,
    [DateCreated]                DATETIME2 (7) NOT NULL,
    [DateModified]               DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_PreparationType_PreparationTypeID] PRIMARY KEY CLUSTERED ([PreparationTypeID] ASC)
);

