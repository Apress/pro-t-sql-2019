﻿CREATE TABLE [dbo].[Recipe] (
    [RecipeID]          SMALLINT      IDENTITY (1, 1) NOT NULL,
    [RecipeName]        VARCHAR (25)  NOT NULL,
    [RecipeDescription] VARCHAR (50)  NOT NULL,
    [ServingQuantity]   TINYINT       NOT NULL,
    [MealTypeID]        TINYINT       NOT NULL,
    [PreparationTypeID] TINYINT       NOT NULL,
    [IsActive]          BIT           NOT NULL,
    [DateCreated]       DATETIME2 (7) NOT NULL,
    [DateModified]      DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_Recipe_RecipeID] PRIMARY KEY CLUSTERED ([RecipeID] ASC)
);

