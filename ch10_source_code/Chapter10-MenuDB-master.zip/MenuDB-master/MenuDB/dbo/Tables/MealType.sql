﻿CREATE TABLE [dbo].[MealType] (
    [MealTypeID]          TINYINT       IDENTITY (1, 1) NOT NULL,
    [MealTypeName]        VARCHAR (25)  NOT NULL,
    [MealTypeDescription] VARCHAR (50)  NOT NULL,
    [IsActive]            BIT           NOT NULL,
    [DateCreated]         DATETIME2 (7) NOT NULL,
    [DateModified]        DATETIME2 (7) NOT NULL,
    CONSTRAINT [PK_MealType_MealTypeID] PRIMARY KEY CLUSTERED ([MealTypeID] ASC)
);


GO
CREATE TRIGGER dbo.DisableMealType  
ON dbo.MealType  
INSTEAD OF DELETE  
AS 
	IF (ROWCOUNT_BIG() = 0)
	RETURN;

	UPDATE meal
	SET IsActive = 0
	FROM dbo.MealType meal
		INNER JOIN deleted del
		ON meal.MealTypeID = del.MealTypeID;  
