﻿CREATE PROCEDURE dbo.GetRecipeByRecipeID
      @RecipeID   INT
AS

      SELECT 
            RecipeID, 
            RecipeName, 
            RecipeDescription, 
            ServingQuantity, 
            MealTypeID, 
            PreparationTypeID, 
            IsActive, 
            DateCreated, 
            DateModified
      FROM dbo.Recipe
      WHERE RecipeID = @RecipeID;