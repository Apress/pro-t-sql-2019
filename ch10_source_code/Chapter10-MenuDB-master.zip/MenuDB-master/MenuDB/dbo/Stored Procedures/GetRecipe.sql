﻿CREATE PROCEDURE dbo.GetRecipe

AS

      SELECT RecipeID, 
            RecipeName, 
            RecipeDescription, 
            ServingQuantity, 
            MealTypeID, 
            PreparationTypeID, 
            IsActive, 
            DateCreated, 
            DateModified
      FROM dbo.Recipe;
