﻿CREATE VIEW dbo.AvailableMeal
WITH SCHEMABINDING
AS
SELECT meal.MealTypeName, meal.MealTypeDescription, meal.IsActive, meal.DateCreated, meal.DateModified, rec.RecipeName, rec.ServingQuantity, ing.IngredientName
FROM dbo.Recipe rec
	INNER JOIN dbo.MealType meal
	ON rec.MealTypeID = meal.MealTypeID
	INNER JOIN dbo.RecipeIngredient recing
	ON rec.RecipeID = recing.RecipeID
	INNER JOIN dbo.Ingredient ing
	ON recing.IngredientID = ing.IngredientID
